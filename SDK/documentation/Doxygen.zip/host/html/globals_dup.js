var globals_dup =
[
    [ "a", "globals.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "e", "globals_e.html", null ],
    [ "h", "globals_h.html", null ],
    [ "i", "globals_i.html", null ],
    [ "l", "globals_l.html", null ],
    [ "m", "globals_m.html", null ],
    [ "o", "globals_o.html", null ],
    [ "q", "globals_q.html", null ],
    [ "r", "globals_r.html", null ],
    [ "s", "globals_s.html", null ]
];