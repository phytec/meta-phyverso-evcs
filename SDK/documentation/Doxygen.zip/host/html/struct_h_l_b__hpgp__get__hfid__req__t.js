var struct_h_l_b__hpgp__get__hfid__req__t =
[
    [ "hfid", "struct_h_l_b__hpgp__get__hfid__req__t.html#a21daf550abaee7aa4ce4c2fee6888a1c", null ],
    [ "nid", "struct_h_l_b__hpgp__get__hfid__req__t.html#a3fb6b275b41635f18d28ed56f791de08", null ],
    [ "req_type", "struct_h_l_b__hpgp__get__hfid__req__t.html#a26d06087b5cb176394f9d2a79acb962f", null ]
];