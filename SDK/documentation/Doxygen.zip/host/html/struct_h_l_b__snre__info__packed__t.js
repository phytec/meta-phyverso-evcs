var struct_h_l_b__snre__info__packed__t =
[
    [ "snre", "struct_h_l_b__snre__info__packed__t.html#a45ebed072f4d16e22d303cf81ba39362", null ],
    [ "status", "struct_h_l_b__snre__info__packed__t.html#a2654142f8c9f37cbede0d0441a2ce467", null ]
];