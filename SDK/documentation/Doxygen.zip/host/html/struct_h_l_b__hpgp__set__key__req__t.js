var struct_h_l_b__hpgp__set__key__req__t =
[
    [ "nid", "struct_h_l_b__hpgp__set__key__req__t.html#abadcee139a61f0200efb7f04a70ae36b", null ],
    [ "nmk", "struct_h_l_b__hpgp__set__key__req__t.html#ae9c8f60c25769e62ede43f9c05ca39c9", null ],
    [ "security_level", "struct_h_l_b__hpgp__set__key__req__t.html#a2af02f771142711df499fa59bc350485", null ]
];