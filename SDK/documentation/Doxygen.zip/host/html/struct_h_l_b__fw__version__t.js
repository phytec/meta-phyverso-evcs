var struct_h_l_b__fw__version__t =
[
    [ "fw_version_build", "struct_h_l_b__fw__version__t.html#a2a21f9ae188683d014415a2f10ff3154", null ],
    [ "fw_version_major", "struct_h_l_b__fw__version__t.html#a395deab1f10831b628fb97168fd1176c", null ],
    [ "fw_version_minor", "struct_h_l_b__fw__version__t.html#a74ebfcbeb0cd68cb2ae31e987e3d6d5f", null ],
    [ "fw_version_patch_version", "struct_h_l_b__fw__version__t.html#a5360e590ec8cc0774fc7f63caf53c4fa", null ],
    [ "fw_version_sub", "struct_h_l_b__fw__version__t.html#aa333d6568f1fe9c195cd67285f3b8ec3", null ]
];