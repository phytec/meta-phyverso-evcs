var struct_h_l_b__read__mem__cnf__packed__t =
[
    [ "data", "struct_h_l_b__read__mem__cnf__packed__t.html#a5e489812b5978d0a4afcf54937442cc2", null ],
    [ "size", "struct_h_l_b__read__mem__cnf__packed__t.html#a19b2c1b6bd3b45219e3f2f207318fd55", null ]
];