var struct_h_l_b__ce2__info__packed__t =
[
    [ "ce2_shift", "struct_h_l_b__ce2__info__packed__t.html#abce037b95fd1b9e43d67ec63669c6ffc", null ],
    [ "gain", "struct_h_l_b__ce2__info__packed__t.html#a990be9c2b864b40485609eb5180562bd", null ],
    [ "status", "struct_h_l_b__ce2__info__packed__t.html#ae90d202c6e7c4b42c0c17ad694bb0d27", null ],
    [ "total_buffer_size", "struct_h_l_b__ce2__info__packed__t.html#aab6cb5a2191bb09382b5f0da2215ec01", null ]
];