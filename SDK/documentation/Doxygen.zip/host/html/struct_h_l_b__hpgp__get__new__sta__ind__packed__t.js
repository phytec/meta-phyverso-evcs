var struct_h_l_b__hpgp__get__new__sta__ind__packed__t =
[
    [ "num_of_new_sta", "struct_h_l_b__hpgp__get__new__sta__ind__packed__t.html#aaf92d2d38f66f1a5e506a7c924df0f33", null ],
    [ "stations", "struct_h_l_b__hpgp__get__new__sta__ind__packed__t.html#a2afe6046842b0138275d038d5c9aacc2", null ]
];