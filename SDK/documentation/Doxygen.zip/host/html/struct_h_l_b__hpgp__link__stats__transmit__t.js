var struct_h_l_b__hpgp__link__stats__transmit__t =
[
    [ "beacon_period_cnt", "struct_h_l_b__hpgp__link__stats__transmit__t.html#a4126b5e1a6584d27a67b7c6bf98d5f6f", null ],
    [ "MPDUs_successfully_acked", "struct_h_l_b__hpgp__link__stats__transmit__t.html#a52f532cf42e065717707e900e1ba8976", null ],
    [ "MPDUs_transmitted", "struct_h_l_b__hpgp__link__stats__transmit__t.html#a9d7e3e4642006fd11496965eae048484", null ],
    [ "MSDUs", "struct_h_l_b__hpgp__link__stats__transmit__t.html#aaf78ce6a26121410db5670c6ef57b5ce", null ],
    [ "octets", "struct_h_l_b__hpgp__link__stats__transmit__t.html#ac90c313b8b18006a444d9670555fbe4c", null ],
    [ "PBs_handed", "struct_h_l_b__hpgp__link__stats__transmit__t.html#a03c191cf64bf66952a6111c803b5a60a", null ],
    [ "segments_delivered", "struct_h_l_b__hpgp__link__stats__transmit__t.html#a64506d33dd6f9f55c601686f8634742a", null ],
    [ "segments_dropped", "struct_h_l_b__hpgp__link__stats__transmit__t.html#a3ba99be23d9098d24926ce917625391e", null ],
    [ "segments_generated", "struct_h_l_b__hpgp__link__stats__transmit__t.html#a162f711d1c047ab46ac94c8a761c570e", null ]
];