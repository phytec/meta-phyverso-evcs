var struct_b_i_n__image__section__header__t =
[
    [ "address", "struct_b_i_n__image__section__header__t.html#a3b61362e6bec7d1fa49ee72cc6eae4b8", null ],
    [ "offset", "struct_b_i_n__image__section__header__t.html#a9dc016b44f5010a6d6b34025c70f54ff", null ],
    [ "sectionName", "struct_b_i_n__image__section__header__t.html#abb5a9b2b7b8ee576f24b803f4907898e", null ],
    [ "size", "struct_b_i_n__image__section__header__t.html#a61493038c798e52a3c07b05fe539c230", null ]
];