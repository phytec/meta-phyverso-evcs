var struct_h_l_b__hpgp__unassociated__sta__ind__packed__t =
[
    [ "cco_cap", "struct_h_l_b__hpgp__unassociated__sta__ind__packed__t.html#a30cd7270e53cb1d8e3e0f74f9c2af2af", null ],
    [ "nid", "struct_h_l_b__hpgp__unassociated__sta__ind__packed__t.html#ae16708741fd8c72621973c57ead0f29b", null ]
];