var struct_h_l_b__hpgp__get__hfid__cnf__t =
[
    [ "hfid", "struct_h_l_b__hpgp__get__hfid__cnf__t.html#acd59337c3a509b04e1d844c701d157b1", null ],
    [ "req_type", "struct_h_l_b__hpgp__get__hfid__cnf__t.html#ac97479e2d7120469ba73fcaec287d6fd", null ]
];