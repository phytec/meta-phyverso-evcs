var struct_h_l_b__hpgp__link__stats__receive__t =
[
    [ "beacon_period_cnt", "struct_h_l_b__hpgp__link__stats__receive__t.html#a004117b5ed91881d658368e1efd8bff4", null ],
    [ "failed_icv_received_frames", "struct_h_l_b__hpgp__link__stats__receive__t.html#abf0f47951d676e2c83d335c1415842bc", null ],
    [ "MPDUs_received", "struct_h_l_b__hpgp__link__stats__receive__t.html#a436e7066997b6bbc12cc4f27db0eb35f", null ],
    [ "MSDUs", "struct_h_l_b__hpgp__link__stats__receive__t.html#aa528d0b0a128333904840531b777d5e1", null ],
    [ "octets", "struct_h_l_b__hpgp__link__stats__receive__t.html#a1cc3962773e0718e5f1201d48967d19e", null ],
    [ "PBs_handed", "struct_h_l_b__hpgp__link__stats__receive__t.html#a9cc6288b8a403ab5f3c549d62d747a73", null ],
    [ "segments_missed", "struct_h_l_b__hpgp__link__stats__receive__t.html#a2fa1041bde8e2cd2fd1418e4ac120047", null ],
    [ "segments_received", "struct_h_l_b__hpgp__link__stats__receive__t.html#a8bd48a94c038bcc8be9210a2b3ee6b84", null ]
];