var struct_h_l_b__hpgp__get__security__mode__cnf__t =
[
    [ "result", "struct_h_l_b__hpgp__get__security__mode__cnf__t.html#a075b6e15d5b044f7e8a21854604fedc6", null ],
    [ "security_mode", "struct_h_l_b__hpgp__get__security__mode__cnf__t.html#a7a2d719bec90b81e38caa2fc0306190c", null ]
];