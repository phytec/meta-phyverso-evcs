var struct_h_l_b__management__header__t =
[
    [ "fragmetation", "struct_h_l_b__management__header__t.html#ab286b979f8cbaaadf1afb9b7f67b485d", null ],
    [ "mmv", "struct_h_l_b__management__header__t.html#add1a79d34053fa2e60440830e06dfd07", null ],
    [ "msg_id", "struct_h_l_b__management__header__t.html#abcb4b66c327c93aff328f23cb6831cac", null ]
];