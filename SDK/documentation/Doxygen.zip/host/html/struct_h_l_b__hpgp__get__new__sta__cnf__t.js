var struct_h_l_b__hpgp__get__new__sta__cnf__t =
[
    [ "num_of_new_sta", "struct_h_l_b__hpgp__get__new__sta__cnf__t.html#a8654391d3e04ccf09dc7704c7c38011c", null ],
    [ "stations", "struct_h_l_b__hpgp__get__new__sta__cnf__t.html#a02cc1b79381eeb6f9bc0f2728eaa33ca", null ]
];