var struct_h_l_b__hpgp__nwinfo__t =
[
    [ "access", "struct_h_l_b__hpgp__nwinfo__t.html#a78007d10e9cf7d5654a7b1cdb23e30b5", null ],
    [ "cco_mac_addr", "struct_h_l_b__hpgp__nwinfo__t.html#a8ef9a5db55624fd82034bfd35ab625e9", null ],
    [ "nid", "struct_h_l_b__hpgp__nwinfo__t.html#a89a143408a93645687aac5a3b373fa14", null ],
    [ "num_cord_neighbor_networks", "struct_h_l_b__hpgp__nwinfo__t.html#aa6999308b880ea79696a8cb42481f0dd", null ],
    [ "short_nid", "struct_h_l_b__hpgp__nwinfo__t.html#a7cc8fc77b0003351d52ef966cd6ea20a", null ],
    [ "sta_role", "struct_h_l_b__hpgp__nwinfo__t.html#a41ac788274cb2586db77202e6a073d71", null ],
    [ "terminal_equipment_id", "struct_h_l_b__hpgp__nwinfo__t.html#a269641e8300a3e6d0b9eddac875f9f5c", null ]
];