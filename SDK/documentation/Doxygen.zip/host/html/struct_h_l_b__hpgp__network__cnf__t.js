var struct_h_l_b__hpgp__network__cnf__t =
[
    [ "hfid", "struct_h_l_b__hpgp__network__cnf__t.html#ae1777302e81c29609686a32b3a0e5004", null ],
    [ "mac_addr", "struct_h_l_b__hpgp__network__cnf__t.html#a2121e1ecedbce1e7c0c439d648f21a65", null ],
    [ "nid", "struct_h_l_b__hpgp__network__cnf__t.html#a60084f02d4f09e79071e101a078f39ec", null ],
    [ "status", "struct_h_l_b__hpgp__network__cnf__t.html#adf26f0fed793c6ddb846cdb841633b16", null ]
];