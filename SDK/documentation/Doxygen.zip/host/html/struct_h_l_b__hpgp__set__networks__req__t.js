var struct_h_l_b__hpgp__set__networks__req__t =
[
    [ "nid", "struct_h_l_b__hpgp__set__networks__req__t.html#ac254a04c85eb38cefa53f5d4a4d51c34", null ],
    [ "req_type", "struct_h_l_b__hpgp__set__networks__req__t.html#a6b2761e4788f1faf0cf50226319dbcc2", null ]
];