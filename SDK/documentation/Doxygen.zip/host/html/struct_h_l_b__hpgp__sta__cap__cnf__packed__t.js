var struct_h_l_b__hpgp__sta__cap__cnf__packed__t =
[
    [ "auto_connect", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#a70b27f0b0d8414d5d41c3443bfecb3f7", null ],
    [ "av_version", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#adc0ff9e536221204094294995456059e", null ],
    [ "backup_cco_capable", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#ace3b160997e0df4116d29c83077f7604", null ],
    [ "bidirectional_burst", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#a8aaab10cf5b2b2a61256b19bfe028faa", null ],
    [ "cco_cap", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#ab77c077962d824b25b4197306ca82d88", null ],
    [ "home_plug_1_0_interop", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#ab2c02b4ec16b618fa12eeafdd9be18e7", null ],
    [ "home_plug_1_1_cap", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#a2830b3878d99b0328e1888d2b4f1f323", null ],
    [ "implementation_ver", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#af30c146fb07785d5b07ed3a6838939af", null ],
    [ "mac_addr", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#ad4e87b26b5f64ae91fc5ffc053446b8e", null ],
    [ "max_fl_av", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#a657fafd01dcc0fbd0e74d261ec2ce053", null ],
    [ "oui", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#ad5ad8b874649e79740ad771600d75db1", null ],
    [ "proxy_capable", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#a183e391b23bb0a58754a5bf339a78f8b", null ],
    [ "regulatory_cap", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#a6ca8daa8bfec4fba05151610af598a50", null ],
    [ "smoothing", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#a4e2daa43b563190c284e2d1979707721", null ],
    [ "soft_handover", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#ad98ea1e9db640d0cc50371ff91eee301", null ],
    [ "two_sym_frame_control", "struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#a6744b1d00ccad2a1a19e0eaf3e074c4d", null ]
];