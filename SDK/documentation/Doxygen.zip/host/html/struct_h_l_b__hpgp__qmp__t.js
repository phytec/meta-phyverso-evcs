var struct_h_l_b__hpgp__qmp__t =
[
    [ "body", "struct_h_l_b__hpgp__qmp__t.html#ac13c8b72daf2058c7a6a996865ce422c", null ],
    [ "field_id", "struct_h_l_b__hpgp__qmp__t.html#ab4252e80cc4c11408d416d6a86720243", null ],
    [ "forward_reserve", "struct_h_l_b__hpgp__qmp__t.html#a1286dcfbd1e2fcaf20111c08336d99e7", null ],
    [ "len", "struct_h_l_b__hpgp__qmp__t.html#afc8b345e8acb1d6cf50c7168c86a4b99", null ]
];