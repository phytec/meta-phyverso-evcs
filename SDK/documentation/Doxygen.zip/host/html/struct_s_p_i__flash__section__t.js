var struct_s_p_i__flash__section__t =
[
    [ "magic_num", "struct_s_p_i__flash__section__t.html#aa23067b1436e05675f998f693898db80", null ],
    [ "offset", "struct_s_p_i__flash__section__t.html#ae17810002dca848ff23ba7d2d795e62c", null ],
    [ "target_addr", "struct_s_p_i__flash__section__t.html#ab42185fc713161313c0c75d2d4c42aa4", null ]
];