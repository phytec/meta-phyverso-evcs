var structversion__t =
[
    [ "version_build", "structversion__t.html#a15a6011d6823a595d88196c6237e1027", null ],
    [ "version_major", "structversion__t.html#a5950fccc3cb761d8c4d0bec77091b0d4", null ],
    [ "version_minor", "structversion__t.html#a2316c5bff42596ffe18987e1e19eab76", null ],
    [ "version_patch", "structversion__t.html#a82e58ca4e2eda33e1624f45cd17adb84", null ]
];