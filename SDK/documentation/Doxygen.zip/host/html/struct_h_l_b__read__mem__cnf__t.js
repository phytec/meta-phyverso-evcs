var struct_h_l_b__read__mem__cnf__t =
[
    [ "data", "struct_h_l_b__read__mem__cnf__t.html#a36cef214f86a5ac97ef778e77b71e2d5", null ],
    [ "size", "struct_h_l_b__read__mem__cnf__t.html#afea85dfc7cf7909d65602eaaad4026cf", null ]
];