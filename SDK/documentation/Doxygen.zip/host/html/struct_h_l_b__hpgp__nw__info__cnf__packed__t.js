var struct_h_l_b__hpgp__nw__info__cnf__packed__t =
[
    [ "num_of_nw_info", "struct_h_l_b__hpgp__nw__info__cnf__packed__t.html#aa431aeca6b1b8043a3e649709f9a2ede", null ],
    [ "nwinfo", "struct_h_l_b__hpgp__nw__info__cnf__packed__t.html#a0dc019c5840a498c27bdc27aef3dccb9", null ]
];