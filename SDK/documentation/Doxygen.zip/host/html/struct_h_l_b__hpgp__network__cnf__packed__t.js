var struct_h_l_b__hpgp__network__cnf__packed__t =
[
    [ "hfid", "struct_h_l_b__hpgp__network__cnf__packed__t.html#a334e21cf3afa68498a371d27e4b0a9cb", null ],
    [ "mac_addr", "struct_h_l_b__hpgp__network__cnf__packed__t.html#a3990f37ffcb0f93104a587de19226c99", null ],
    [ "nid", "struct_h_l_b__hpgp__network__cnf__packed__t.html#a5d9682a892c4fe6645b33a3661b2a33e", null ],
    [ "status", "struct_h_l_b__hpgp__network__cnf__packed__t.html#a93ffd15401c1366e5b7949c5a67656b5", null ]
];