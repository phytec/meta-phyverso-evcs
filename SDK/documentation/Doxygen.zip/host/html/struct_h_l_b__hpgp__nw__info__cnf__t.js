var struct_h_l_b__hpgp__nw__info__cnf__t =
[
    [ "num_of_nw_info", "struct_h_l_b__hpgp__nw__info__cnf__t.html#aeb285cfa2d073781dfa507bc2d5033cf", null ],
    [ "nwinfo", "struct_h_l_b__hpgp__nw__info__cnf__t.html#ab2ba0e1c946265dd23ff1c23195d8b93", null ]
];