var struct_h_l_b__hpgp__set__networks__req__packed__t =
[
    [ "nid", "struct_h_l_b__hpgp__set__networks__req__packed__t.html#a1b4d065ff1f50e5ccdc0f5327e1ab335", null ],
    [ "req_type", "struct_h_l_b__hpgp__set__networks__req__packed__t.html#a83287a70e7524077d5a509ec4135d93d", null ]
];