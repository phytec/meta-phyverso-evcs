var struct_h_l_b__hpgp__beacon__mgmt__info__packed__t =
[
    [ "beacon_entries", "struct_h_l_b__hpgp__beacon__mgmt__info__packed__t.html#a81bd7900111a52880274cd3edf721207", null ],
    [ "num_of_beacon_entries", "struct_h_l_b__hpgp__beacon__mgmt__info__packed__t.html#abe452b007b59d54021651b52c9077fa4", null ]
];