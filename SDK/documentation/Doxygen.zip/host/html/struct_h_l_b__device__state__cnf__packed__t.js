var struct_h_l_b__device__state__cnf__packed__t =
[
    [ "device_state", "struct_h_l_b__device__state__cnf__packed__t.html#a1e60a2c5ba5ff4e8b7e69e2f31eaccff", null ]
];