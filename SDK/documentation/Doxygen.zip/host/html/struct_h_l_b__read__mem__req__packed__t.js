var struct_h_l_b__read__mem__req__packed__t =
[
    [ "address", "struct_h_l_b__read__mem__req__packed__t.html#a5e546a5f5c913fb7a4f59ff2ca75e873", null ],
    [ "size", "struct_h_l_b__read__mem__req__packed__t.html#ae3d2ae4bdc9654740567fce8073d837e", null ]
];