var struct_h_l_b__hpgp__get__hfid__cnf__packed__t =
[
    [ "hfid", "struct_h_l_b__hpgp__get__hfid__cnf__packed__t.html#a718c6881a8b65fe2decffe686bf95250", null ],
    [ "req_type", "struct_h_l_b__hpgp__get__hfid__cnf__packed__t.html#ad38c8b63e42b4f0be0a729638c07f923", null ]
];