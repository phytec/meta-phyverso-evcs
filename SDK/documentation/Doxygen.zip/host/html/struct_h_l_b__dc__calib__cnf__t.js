var struct_h_l_b__dc__calib__cnf__t =
[
    [ "dc_offset_hi_ch1", "struct_h_l_b__dc__calib__cnf__t.html#a1e92f0b275d15b734a26f26a72fa2342", null ],
    [ "dc_offset_lo_ch1", "struct_h_l_b__dc__calib__cnf__t.html#a8288cd678fe80680993c9ef73d13d454", null ]
];