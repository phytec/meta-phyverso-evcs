var struct_h_l_b__fw__version__packed__t =
[
    [ "fw_version_build", "struct_h_l_b__fw__version__packed__t.html#ad7ac908e98818086f7752062cf8f6b7d", null ],
    [ "fw_version_major", "struct_h_l_b__fw__version__packed__t.html#afddffeb6d0f33afbf539f9e321060294", null ],
    [ "fw_version_minor", "struct_h_l_b__fw__version__packed__t.html#a8571e817d03c77809e39ab2bd7f55583", null ],
    [ "fw_version_patch_version", "struct_h_l_b__fw__version__packed__t.html#a91b2d7de5d38f91142c6c7c446352c5b", null ],
    [ "fw_version_sub", "struct_h_l_b__fw__version__packed__t.html#aaa6d8fcdf49c6ddad1e40c89b6111a5b", null ]
];