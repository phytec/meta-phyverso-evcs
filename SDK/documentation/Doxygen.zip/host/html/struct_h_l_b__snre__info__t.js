var struct_h_l_b__snre__info__t =
[
    [ "snre", "struct_h_l_b__snre__info__t.html#ab6a69143042f53470138cd46b29763a8", null ],
    [ "status", "struct_h_l_b__snre__info__t.html#a4a3e847e867b1717f8ecd444a21f85f2", null ]
];