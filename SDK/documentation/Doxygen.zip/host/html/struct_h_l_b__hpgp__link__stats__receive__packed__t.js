var struct_h_l_b__hpgp__link__stats__receive__packed__t =
[
    [ "beacon_period_cnt", "struct_h_l_b__hpgp__link__stats__receive__packed__t.html#ae06a6a38afc0d33ed63ff7ea2e8462a7", null ],
    [ "failed_icv_received_frames", "struct_h_l_b__hpgp__link__stats__receive__packed__t.html#a962c7bc8f89728945b49dabc2004659d", null ],
    [ "MPDUs_received", "struct_h_l_b__hpgp__link__stats__receive__packed__t.html#a6a5282eab9a13103f838bab5df98a325", null ],
    [ "MSDUs", "struct_h_l_b__hpgp__link__stats__receive__packed__t.html#a6868730cfb7caa1ca868c3bb9d1ab89f", null ],
    [ "octets", "struct_h_l_b__hpgp__link__stats__receive__packed__t.html#a54b9cf1580e7a251f51269bede205897", null ],
    [ "PBs_handed", "struct_h_l_b__hpgp__link__stats__receive__packed__t.html#a24619eb7b88508be20458cc886cd5624", null ],
    [ "segments_missed", "struct_h_l_b__hpgp__link__stats__receive__packed__t.html#a6b105e44dfa4d5f230a02e256fd1d4ed", null ],
    [ "segments_received", "struct_h_l_b__hpgp__link__stats__receive__packed__t.html#a6b6a0294700c784a78b71bdaa20e7b16", null ]
];