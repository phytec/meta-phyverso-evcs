var struct_h_l_b__dc__calib__cnf__packed__t =
[
    [ "dc_offset_hi_ch1", "struct_h_l_b__dc__calib__cnf__packed__t.html#a09c841b3494d715a2f4b9edc18921dc6", null ],
    [ "dc_offset_lo_ch1", "struct_h_l_b__dc__calib__cnf__packed__t.html#a408da8f69669e81a799f3599fa72049e", null ]
];