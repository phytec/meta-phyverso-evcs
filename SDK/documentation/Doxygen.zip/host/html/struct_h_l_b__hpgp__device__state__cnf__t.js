var struct_h_l_b__hpgp__device__state__cnf__t =
[
    [ "device_status", "struct_h_l_b__hpgp__device__state__cnf__t.html#ac17c9948ff07390c407b983d6e96abd0", null ]
];