var struct_h_l_b__hpgp__link__stats__req__t =
[
    [ "da_sa_mac_addr", "struct_h_l_b__hpgp__link__stats__req__t.html#a940b12ef30322872516979f85d3a6b7e", null ],
    [ "nid", "struct_h_l_b__hpgp__link__stats__req__t.html#af6c3a7362a278ca7c3b1b5bcf87b176f", null ],
    [ "req_type", "struct_h_l_b__hpgp__link__stats__req__t.html#a0055bee9f055f9a8e76e7eaade66539e", null ],
    [ "transmit_link_flag", "struct_h_l_b__hpgp__link__stats__req__t.html#a3599b97cd8c9acc82f8fc2263a35a838", null ]
];