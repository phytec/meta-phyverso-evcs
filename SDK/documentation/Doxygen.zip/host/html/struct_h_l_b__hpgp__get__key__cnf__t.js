var struct_h_l_b__hpgp__get__key__cnf__t =
[
    [ "nid", "struct_h_l_b__hpgp__get__key__cnf__t.html#a908c58d998f2515ef1ca16216c2a7757", null ],
    [ "nmk", "struct_h_l_b__hpgp__get__key__cnf__t.html#a27e20d3f8d3026b08afae50f71b16737", null ]
];