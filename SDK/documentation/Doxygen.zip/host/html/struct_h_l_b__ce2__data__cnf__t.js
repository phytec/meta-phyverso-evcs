var struct_h_l_b__ce2__data__cnf__t =
[
    [ "data", "struct_h_l_b__ce2__data__cnf__t.html#afe27b35a4b6f6b23c14658f121a72a32", null ],
    [ "size", "struct_h_l_b__ce2__data__cnf__t.html#ae4d37ec63dad1de90132bc6bfff8081a", null ],
    [ "status", "struct_h_l_b__ce2__data__cnf__t.html#a4914142e236739f6ad54a9ccb4dfd77f", null ]
];