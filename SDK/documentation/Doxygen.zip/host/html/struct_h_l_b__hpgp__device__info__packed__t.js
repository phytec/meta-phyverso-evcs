var struct_h_l_b__hpgp__device__info__packed__t =
[
    [ "avln_hfid", "struct_h_l_b__hpgp__device__info__packed__t.html#ab339cea1b8b749dda0a8bf4d45e4176d", null ],
    [ "connectivity_config", "struct_h_l_b__hpgp__device__info__packed__t.html#a249c7d9bfecaba67762e5c735f6a2875", null ],
    [ "mac_addr", "struct_h_l_b__hpgp__device__info__packed__t.html#a8378e4e8168e4e4647663ef683286b9e", null ],
    [ "manufacturer_hfid", "struct_h_l_b__hpgp__device__info__packed__t.html#a842a3f5d7be24ce92fd3b6451edd72aa", null ],
    [ "max_receiver_sensitivity", "struct_h_l_b__hpgp__device__info__packed__t.html#a1b8dd5423ddaf53945d0bc8a5fce1805", null ],
    [ "nid", "struct_h_l_b__hpgp__device__info__packed__t.html#a0d7b97d844b7ed175489b63f200203f1", null ],
    [ "nmk", "struct_h_l_b__hpgp__device__info__packed__t.html#ac40ae58f054e11d61210bdb55ec68b99", null ],
    [ "plc_freq_sel", "struct_h_l_b__hpgp__device__info__packed__t.html#ae27586551f5067cc4ec4ed0d21a9ba5f", null ],
    [ "security_level", "struct_h_l_b__hpgp__device__info__packed__t.html#a63cf478a3aafc10a7f7ca05f7e7cca27", null ],
    [ "snid", "struct_h_l_b__hpgp__device__info__packed__t.html#ad6f4a75d98875bb72bb3dcf1a82eaff6", null ],
    [ "terminal_equipment_id", "struct_h_l_b__hpgp__device__info__packed__t.html#aae9a4486a31df69ae4269f640683770d", null ],
    [ "user_hfid", "struct_h_l_b__hpgp__device__info__packed__t.html#afb82e7f4d2d8026066b216bda02b7f21", null ]
];