var struct_h_l_b__hpgp__cinfo__t =
[
    [ "arrival_timestamp_to_hle", "struct_h_l_b__hpgp__cinfo__t.html#abf0b497c275aef0978a75f1a141e9821", null ],
    [ "mac_service_type", "struct_h_l_b__hpgp__cinfo__t.html#ac1d356cba9fd718b9dd66ca80b33d186", null ],
    [ "smoothing", "struct_h_l_b__hpgp__cinfo__t.html#a47c05ed41427041d0529e6a1af76706b", null ],
    [ "user_priority", "struct_h_l_b__hpgp__cinfo__t.html#ab2e30a75be5a4a0e84c1159963970c39", null ],
    [ "valid_cinfo", "struct_h_l_b__hpgp__cinfo__t.html#aaa5855afce48b079cff179d7c06300e6", null ]
];