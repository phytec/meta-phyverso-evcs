var struct_r_o_o_t__header__t =
[
    [ "app_launch_addr", "struct_r_o_o_t__header__t.html#a5ed4ed90f390fb2abac7f1722b2d5190", null ],
    [ "app_magic_num", "struct_r_o_o_t__header__t.html#a2f83fb3be620eb5c909441deb14fbf1f", null ],
    [ "app_offset", "struct_r_o_o_t__header__t.html#acd506516d39f0baf32001ac55878ad9f", null ],
    [ "app_target_adrr", "struct_r_o_o_t__header__t.html#a0f3781cd1beba8b904e81881e57ffe74", null ],
    [ "BCB_magic_num", "struct_r_o_o_t__header__t.html#ae76ba3148dba668eebf8e0cbd87d7a80", null ],
    [ "BCB_offset", "struct_r_o_o_t__header__t.html#a1e4974b79f1e7855c0544523c49d6935", null ]
];