var struct_b_i_n__section__header__t =
[
    [ "CheckSum", "struct_b_i_n__section__header__t.html#a0c75285510726c982cb123fb1c384794", null ],
    [ "Length", "struct_b_i_n__section__header__t.html#ab9256fa1c623ec6d81fbc7ad5cb814a3", null ],
    [ "Section", "struct_b_i_n__section__header__t.html#a45b32229366a1390153956f4a28fcfa6", null ]
];