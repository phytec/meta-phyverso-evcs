var struct_h_l_b__hpgp__beacon__mgmt__info__t =
[
    [ "beacon_entries", "struct_h_l_b__hpgp__beacon__mgmt__info__t.html#a775cb0d18a9c99e5448407741ab5b787", null ],
    [ "num_of_beacon_entries", "struct_h_l_b__hpgp__beacon__mgmt__info__t.html#a3a2aa58fead406b5100baa2457a21899", null ]
];