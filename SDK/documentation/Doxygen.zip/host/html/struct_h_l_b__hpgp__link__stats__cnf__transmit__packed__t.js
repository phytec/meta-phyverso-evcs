var struct_h_l_b__hpgp__link__stats__cnf__transmit__packed__t =
[
    [ "params", "struct_h_l_b__hpgp__link__stats__cnf__transmit__packed__t.html#a772110d342f3667df986bff7a7f5c6f8", null ],
    [ "transmit_link", "struct_h_l_b__hpgp__link__stats__cnf__transmit__packed__t.html#a3b11e084e3a3d85b14b2445469d36410", null ]
];