var struct_h_l_b__device__info__t =
[
    [ "avln_hfid", "struct_h_l_b__device__info__t.html#a6cbd04dd064e2e919f89b24ac49b9acd", null ],
    [ "cco_mode", "struct_h_l_b__device__info__t.html#a226c91ddc9f7cd6478be4c1a6947c249", null ],
    [ "host_iface", "struct_h_l_b__device__info__t.html#a931baecf8bb0f6fbd19f0e0047b6a82b", null ],
    [ "mac_addr", "struct_h_l_b__device__info__t.html#ad8a310c7bd4f7e3afe03a46f157a048e", null ],
    [ "manufacturer_hfid", "struct_h_l_b__device__info__t.html#aae673437e6ddcf613cd6b8092cfe5f6e", null ],
    [ "max_receiver_sensitivity", "struct_h_l_b__device__info__t.html#ad515c442a57ab232af8d147bd012bef5", null ],
    [ "nid", "struct_h_l_b__device__info__t.html#a643c754695f8dbe9ead785d299e32bff", null ],
    [ "nmk", "struct_h_l_b__device__info__t.html#ac6f4928e9cf95ede2cad003fa974ff2e", null ],
    [ "plc_freq_sel", "struct_h_l_b__device__info__t.html#af3c2d43f94cd1e52c53d8c3f7dc9546e", null ],
    [ "security_level", "struct_h_l_b__device__info__t.html#a13679ed4435da0b9209715fd25224719", null ],
    [ "snid", "struct_h_l_b__device__info__t.html#ab8d3f906c31883344ac4ca48f7eb0582", null ],
    [ "terminal_equipment_id", "struct_h_l_b__device__info__t.html#aab931eab6e6d9dde43fd737774a214dc", null ],
    [ "user_hfid", "struct_h_l_b__device__info__t.html#aa7761d8b82b50c9ea8738a7b867f7ae6", null ]
];