var struct_p_r_o_d__minimal__config__params__packed__t =
[
    [ "cco_role", "struct_p_r_o_d__minimal__config__params__packed__t.html#a60c3b29ff3eec998b738086523a29bf1", null ],
    [ "configuration_binary_version", "struct_p_r_o_d__minimal__config__params__packed__t.html#af8a24d25fbfb9830d8ff7718af2873c6", null ],
    [ "mac_address", "struct_p_r_o_d__minimal__config__params__packed__t.html#a88f13049745f8962221b58657d622f7b", null ],
    [ "nmk", "struct_p_r_o_d__minimal__config__params__packed__t.html#ac396759d4c2d1c5a08221ebcab72dcbe", null ],
    [ "reserved", "struct_p_r_o_d__minimal__config__params__packed__t.html#a1d0159440057543a9f054ac344f13fe6", null ],
    [ "tdu_dacs_b1", "struct_p_r_o_d__minimal__config__params__packed__t.html#a50263cb9eac9122399aadd0465c9ec0c", null ],
    [ "tdu_dacs_shift", "struct_p_r_o_d__minimal__config__params__packed__t.html#a5f9bd49f3664a9c95836d19b13ddde3e", null ],
    [ "version", "struct_p_r_o_d__minimal__config__params__packed__t.html#a696581e813db4fde62032b3be9544de1", null ]
];