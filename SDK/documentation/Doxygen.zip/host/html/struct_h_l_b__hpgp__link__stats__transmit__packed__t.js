var struct_h_l_b__hpgp__link__stats__transmit__packed__t =
[
    [ "beacon_period_cnt", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#a03c59788849ea737c4c9a713e6a00384", null ],
    [ "MPDUs_successfully_acked", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#a4bfbb7691e7b2ff584aecdbfe839f82c", null ],
    [ "MPDUs_transmitted", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#a0dfc6ae3552764d8285ecceba207f941", null ],
    [ "MSDUs", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#a4a324f03bc54381535599966cb1fe07a", null ],
    [ "octets", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#a5fa3d52094272c7e90632e5af2fd36dc", null ],
    [ "PBs_handed", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#a13f91ef8ea73fb229b92a3b5ab1b166d", null ],
    [ "segments_delivered", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#a61bdf6590e032b105c2cd1cac005c1b9", null ],
    [ "segments_dropped", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#a8e0a53cc20b6ae6e8611a2ac0a1a930b", null ],
    [ "segments_generated", "struct_h_l_b__hpgp__link__stats__transmit__packed__t.html#aef41e746afcf481d83795307ebeb47a6", null ]
];