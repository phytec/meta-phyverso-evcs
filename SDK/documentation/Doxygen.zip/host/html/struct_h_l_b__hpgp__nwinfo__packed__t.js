var struct_h_l_b__hpgp__nwinfo__packed__t =
[
    [ "access", "struct_h_l_b__hpgp__nwinfo__packed__t.html#a3647bc136b7b4cc80d22367ab5b4e672", null ],
    [ "cco_mac_addr", "struct_h_l_b__hpgp__nwinfo__packed__t.html#a4da9aa2fc341a72093c20e4a29898d30", null ],
    [ "nid", "struct_h_l_b__hpgp__nwinfo__packed__t.html#afacb2e0a45322d8936876ac3184c585b", null ],
    [ "num_cord_neighbor_networks", "struct_h_l_b__hpgp__nwinfo__packed__t.html#a00e369bc1e5545d79da996ff080d04e3", null ],
    [ "short_nid", "struct_h_l_b__hpgp__nwinfo__packed__t.html#a76e6b26fc58c602ad08254b41d2c7b80", null ],
    [ "sta_role", "struct_h_l_b__hpgp__nwinfo__packed__t.html#ac44739e1ea32dacc35beedada5e46201", null ],
    [ "terminal_equipment_id", "struct_h_l_b__hpgp__nwinfo__packed__t.html#a503ade3c38990829a7ba21845103901a", null ]
];