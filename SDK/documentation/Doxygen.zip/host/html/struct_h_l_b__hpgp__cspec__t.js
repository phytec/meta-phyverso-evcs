var struct_h_l_b__hpgp__cspec__t =
[
    [ "cinfo_forward", "struct_h_l_b__hpgp__cspec__t.html#a6438c3a9fa118350ae445f981cec0dc5", null ],
    [ "cinfo_reverse", "struct_h_l_b__hpgp__cspec__t.html#ab922d175d281218c78e363a92c9cf698", null ],
    [ "cspec_len", "struct_h_l_b__hpgp__cspec__t.html#a9e14d579d6723a4e492c5962f2bfead1", null ],
    [ "qmp_forward", "struct_h_l_b__hpgp__cspec__t.html#affeaf37ba4d5881078b223c77db20a82", null ],
    [ "qmp_reverse", "struct_h_l_b__hpgp__cspec__t.html#a17acdccf57fd35b0cc423bd7ad818a66", null ]
];