var structamplitude__map__packed__t =
[
    [ "amdata", "structamplitude__map__packed__t.html#af9ea6b07241b68946eaa6baa9fcb2553", null ]
];