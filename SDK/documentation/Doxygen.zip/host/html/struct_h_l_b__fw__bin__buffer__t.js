var struct_h_l_b__fw__bin__buffer__t =
[
    [ "buffer", "struct_h_l_b__fw__bin__buffer__t.html#a1aa9251600dd045ff593e040d1c19338", null ],
    [ "buffer_size", "struct_h_l_b__fw__bin__buffer__t.html#ab5120e1a1f6494256603bf3a02021136", null ]
];