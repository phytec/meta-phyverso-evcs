var struct_h_l_b__write__mem__req__packed__t =
[
    [ "address", "struct_h_l_b__write__mem__req__packed__t.html#a616cd3dc0ebdbc6e02136135cbd876fa", null ],
    [ "data", "struct_h_l_b__write__mem__req__packed__t.html#a701c31d22a90b73f4e4e3936d8488ae4", null ],
    [ "size", "struct_h_l_b__write__mem__req__packed__t.html#a3aa282b71e31ea3fc7014919c9c6a7a8", null ]
];