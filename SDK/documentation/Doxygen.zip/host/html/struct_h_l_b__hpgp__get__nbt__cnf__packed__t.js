var struct_h_l_b__hpgp__get__nbt__cnf__packed__t =
[
    [ "ntb", "struct_h_l_b__hpgp__get__nbt__cnf__packed__t.html#ad9078dcc38c3a5e9a8d8e71b17b73a30", null ]
];