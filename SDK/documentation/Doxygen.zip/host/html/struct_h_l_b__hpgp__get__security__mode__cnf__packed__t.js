var struct_h_l_b__hpgp__get__security__mode__cnf__packed__t =
[
    [ "result", "struct_h_l_b__hpgp__get__security__mode__cnf__packed__t.html#a2b8507954b8c000cd5973602cb7d1930", null ],
    [ "security_mode", "struct_h_l_b__hpgp__get__security__mode__cnf__packed__t.html#a28b37551549ad20ad2f2e01f884227ee", null ]
];