var struct_h_l_b__hpgp__get__hfid__req__packed__type4__t =
[
    [ "hfid", "struct_h_l_b__hpgp__get__hfid__req__packed__type4__t.html#a6ec8afbcd05f16f507d95c5fdd32e814", null ],
    [ "nid", "struct_h_l_b__hpgp__get__hfid__req__packed__type4__t.html#a10c38cf6a142933b15762e72c8060618", null ],
    [ "req_type", "struct_h_l_b__hpgp__get__hfid__req__packed__type4__t.html#a38c4677612a22d7504cc7267bb7772ab", null ]
];