var searchData=
[
  ['comm_5fhandle_5ft_1265',['comm_handle_t',['../common_8h.html#a6e8676fd618c66737a25794dfa2f94b1',1,'common.h']]]
];
