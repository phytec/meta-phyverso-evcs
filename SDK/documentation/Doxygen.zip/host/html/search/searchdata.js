var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuv",
  1: "abehlmprsv",
  2: "chs",
  3: "h",
  4: "abcdefghilmnopqrstuv",
  5: "chimr",
  6: "cdehr",
  7: "cdehr",
  8: "acehlmoqrs",
  9: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

