var searchData=
[
  ['implementation_5fver_1150',['implementation_ver',['../struct_h_l_b__hpgp__sta__cap__cnf__packed__t.html#af30c146fb07785d5b07ed3a6838939af',1,'HLB_hpgp_sta_cap_cnf_packed_t::implementation_ver()'],['../struct_h_l_b__hpgp__sta__cap__cnf__t.html#a199ae9a7a6208e0fad5c16495f723c96',1,'HLB_hpgp_sta_cap_cnf_t::implementation_ver()']]]
];
