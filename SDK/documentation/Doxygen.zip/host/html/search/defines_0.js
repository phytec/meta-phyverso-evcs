var searchData=
[
  ['amdata_5flen_1518',['AMDATA_LEN',['../shared_8h.html#a4798fca11c1bc6ea113aa70e0429302b',1,'shared.h']]]
];
