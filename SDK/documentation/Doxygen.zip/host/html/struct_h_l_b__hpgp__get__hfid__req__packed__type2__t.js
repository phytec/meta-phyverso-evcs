var struct_h_l_b__hpgp__get__hfid__req__packed__type2__t =
[
    [ "nid", "struct_h_l_b__hpgp__get__hfid__req__packed__type2__t.html#a7d39ae52179c6f5af964a7a5047fae62", null ],
    [ "req_type", "struct_h_l_b__hpgp__get__hfid__req__packed__type2__t.html#afd97f7159541185db812c4029964426c", null ]
];