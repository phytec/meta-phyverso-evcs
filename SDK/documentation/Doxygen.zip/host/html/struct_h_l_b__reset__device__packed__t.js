var struct_h_l_b__reset__device__packed__t =
[
    [ "stop_in_hostboot", "struct_h_l_b__reset__device__packed__t.html#aa0e9351f8fbad59a4426228ac54ff9b0", null ]
];