var struct_h_l_b__hpgp__link__stats__cnf__receive__packed__t =
[
    [ "params", "struct_h_l_b__hpgp__link__stats__cnf__receive__packed__t.html#ae2630bacda7cde00ceb787c177f6e649", null ],
    [ "receive_link", "struct_h_l_b__hpgp__link__stats__cnf__receive__packed__t.html#a83df12c30d1706f0bce834001c0fe067", null ]
];