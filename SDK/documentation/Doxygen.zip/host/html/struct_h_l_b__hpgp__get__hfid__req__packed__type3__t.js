var struct_h_l_b__hpgp__get__hfid__req__packed__type3__t =
[
    [ "hfid", "struct_h_l_b__hpgp__get__hfid__req__packed__type3__t.html#a810e7974c7517b4ed79e1adbd5d804d8", null ],
    [ "req_type", "struct_h_l_b__hpgp__get__hfid__req__packed__type3__t.html#aff8549038f462f443015f709da0a9c89", null ]
];