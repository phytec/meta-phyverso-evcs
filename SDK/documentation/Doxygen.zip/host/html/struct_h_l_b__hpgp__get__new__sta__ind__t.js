var struct_h_l_b__hpgp__get__new__sta__ind__t =
[
    [ "num_of_new_sta", "struct_h_l_b__hpgp__get__new__sta__ind__t.html#ace8fea408a20fde7594c83cfd93e1674", null ],
    [ "stations", "struct_h_l_b__hpgp__get__new__sta__ind__t.html#a1bd57f98b419d95f2c708927d9a719ff", null ]
];