var struct_h_l_b__fragmented__packet__t =
[
    [ "layer_2_header", "struct_h_l_b__fragmented__packet__t.html#a278321ff75dc03ea18dfc1a832507c05", null ],
    [ "management_header", "struct_h_l_b__fragmented__packet__t.html#ad4d968447f9d88a3df7fea6e76e0dd89", null ],
    [ "payload", "struct_h_l_b__fragmented__packet__t.html#a57563ff49dd1854673f583fd2c1de1dc", null ]
];