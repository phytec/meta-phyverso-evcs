var struct_h_l_b__write__mem__req__t =
[
    [ "address", "struct_h_l_b__write__mem__req__t.html#ae9648e5ad1cbf296edcc726d51a41f40", null ],
    [ "data", "struct_h_l_b__write__mem__req__t.html#ad8f2457f8196a9a1f86eba1466cdbeea", null ],
    [ "size", "struct_h_l_b__write__mem__req__t.html#a91b681824aaa604b2954737b385995bb", null ]
];