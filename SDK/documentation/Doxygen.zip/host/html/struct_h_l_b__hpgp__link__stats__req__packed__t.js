var struct_h_l_b__hpgp__link__stats__req__packed__t =
[
    [ "da_sa_mac_addr", "struct_h_l_b__hpgp__link__stats__req__packed__t.html#a995d6039a4dee30deb4cd94260a54265", null ],
    [ "nid", "struct_h_l_b__hpgp__link__stats__req__packed__t.html#a19cda86ed0b4c55c468a06156a4afe23", null ],
    [ "req_type", "struct_h_l_b__hpgp__link__stats__req__packed__t.html#aa9e4a600fa131b8f97e35b68868b2407", null ],
    [ "transmit_link_flag", "struct_h_l_b__hpgp__link__stats__req__packed__t.html#af4ece252c642d591bb4e7fda43b8d1c9", null ]
];