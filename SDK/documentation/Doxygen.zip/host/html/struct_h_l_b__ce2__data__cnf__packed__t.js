var struct_h_l_b__ce2__data__cnf__packed__t =
[
    [ "data", "struct_h_l_b__ce2__data__cnf__packed__t.html#a88ba1637c3b526c655f68d7c9425d2e2", null ],
    [ "size", "struct_h_l_b__ce2__data__cnf__packed__t.html#a43960f2424cf0670bac0565ce1cb6e60", null ],
    [ "status", "struct_h_l_b__ce2__data__cnf__packed__t.html#ae514f5aa22d1fa97e522804963156c17", null ]
];