var struct_h_l_b__hpgp__unassociated__sta__ind__t =
[
    [ "cco_cap", "struct_h_l_b__hpgp__unassociated__sta__ind__t.html#a49c53101e21eea8a4af4d7f5e57ca052", null ],
    [ "nid", "struct_h_l_b__hpgp__unassociated__sta__ind__t.html#abeecaf33bf206c86ed869dad7b605bbf", null ]
];