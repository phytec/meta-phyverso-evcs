var struct_p_r_o_d__configuration__content__packed__t =
[
    [ "amb_tx_dac_shift_table_idx", "struct_p_r_o_d__configuration__content__packed__t.html#a2a3144961ec1c0c28036b15169b747d6", null ],
    [ "amb_tx_dac_table_idx", "struct_p_r_o_d__configuration__content__packed__t.html#af6579c2c528432bb92c7dea676c3a4d7", null ],
    [ "analog_gain_code", "struct_p_r_o_d__configuration__content__packed__t.html#a1faada93286932c3b73bed62c43608c6", null ],
    [ "avln_hfid", "struct_p_r_o_d__configuration__content__packed__t.html#ab87185e942a2aab1ea1f2cc2eec2787a", null ],
    [ "cg_drive_strength_rxd_0_1_2_3_and_rx_dv", "struct_p_r_o_d__configuration__content__packed__t.html#ac51e2370da8056205f676e00eb67ea82", null ],
    [ "cg_drive_strength_tx_clk", "struct_p_r_o_d__configuration__content__packed__t.html#ab1fa83917cf9bd3c89ccae5c4cb40734", null ],
    [ "host_interface", "struct_p_r_o_d__configuration__content__packed__t.html#a1c8794c50c005a41161a8f6c276983f3", null ],
    [ "host_internal_data_PSD_gain", "struct_p_r_o_d__configuration__content__packed__t.html#a29c25aa4fe0755018004ade9655e2a50", null ],
    [ "manu_hfid", "struct_p_r_o_d__configuration__content__packed__t.html#ab58e858efaa8e20ed78e683834e34eb7", null ],
    [ "min_conf", "struct_p_r_o_d__configuration__content__packed__t.html#a498400713708d6a6e7434a9556751bbd", null ],
    [ "nid", "struct_p_r_o_d__configuration__content__packed__t.html#aa28165f9ddc6873130b29dcf984b3a69", null ],
    [ "plc_freq_sel", "struct_p_r_o_d__configuration__content__packed__t.html#a299ec618014b45088e4bc35525a6c013", null ],
    [ "receiver_max_sensitivity", "struct_p_r_o_d__configuration__content__packed__t.html#aeaefc5417ccd46a031d935170c71bd08", null ],
    [ "security_level", "struct_p_r_o_d__configuration__content__packed__t.html#ae77e49676a438b3e821dd9f9287c3d5d", null ],
    [ "user_hfid", "struct_p_r_o_d__configuration__content__packed__t.html#a9ce966f09594396d71d3d550926137cb", null ]
];