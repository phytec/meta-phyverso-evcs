var struct_h_l_b__lnoe__info__packed__t =
[
    [ "data", "struct_h_l_b__lnoe__info__packed__t.html#a6e0b69dc245372bf6876c4bb1ef97bf0", null ],
    [ "gain", "struct_h_l_b__lnoe__info__packed__t.html#a1ffb4763b23a073184a9f7601af6eefd", null ],
    [ "status", "struct_h_l_b__lnoe__info__packed__t.html#aa246e7171122bc9fd553b5b300f609a5", null ]
];