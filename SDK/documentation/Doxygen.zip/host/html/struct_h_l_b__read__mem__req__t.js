var struct_h_l_b__read__mem__req__t =
[
    [ "address", "struct_h_l_b__read__mem__req__t.html#a61cc22b217e7aca460b774f954bb0da6", null ],
    [ "size", "struct_h_l_b__read__mem__req__t.html#ae52a4ce33ddf82b255d83e889fca5e03", null ]
];