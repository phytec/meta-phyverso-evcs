var struct_h_l_b__hpgp__beacon__entry__t =
[
    [ "header", "struct_h_l_b__hpgp__beacon__entry__t.html#a3ec8caac88638ecaf14eea61c398fb23", null ],
    [ "len", "struct_h_l_b__hpgp__beacon__entry__t.html#a1b8a8714c994c68e8154454e23372a27", null ],
    [ "payload", "struct_h_l_b__hpgp__beacon__entry__t.html#af51add72aa47f231d4d859c39912832d", null ]
];