var struct_h_l_b__hpgp__link__stats__cnf__conf__params__packed__t =
[
    [ "res_type", "struct_h_l_b__hpgp__link__stats__cnf__conf__params__packed__t.html#a1a40dd3a67fdbf2cda42452ad6cc20d7", null ],
    [ "transmit_link_flag", "struct_h_l_b__hpgp__link__stats__cnf__conf__params__packed__t.html#a9a467396c5e5253e20f50ee2d4f03d28", null ]
];