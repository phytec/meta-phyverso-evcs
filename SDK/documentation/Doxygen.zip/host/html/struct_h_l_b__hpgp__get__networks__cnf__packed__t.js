var struct_h_l_b__hpgp__get__networks__cnf__packed__t =
[
    [ "networks", "struct_h_l_b__hpgp__get__networks__cnf__packed__t.html#a36785b07ea994c90e993d679fb2036e5", null ],
    [ "num_of_networks", "struct_h_l_b__hpgp__get__networks__cnf__packed__t.html#a3e513479e93d9f367b49fb2b22fbc31f", null ]
];