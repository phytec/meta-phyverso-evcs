var struct_h_l_b__hpgp__get__new__sta__cnf__packed__t =
[
    [ "num_of_new_sta", "struct_h_l_b__hpgp__get__new__sta__cnf__packed__t.html#af1221b34f473451ca31346dfeb047b02", null ],
    [ "stations", "struct_h_l_b__hpgp__get__new__sta__cnf__packed__t.html#a15ad4d6517d4b43173accade22777aeb", null ]
];