var struct_h_l_b__hpgp__get__networks__cnf__t =
[
    [ "networks", "struct_h_l_b__hpgp__get__networks__cnf__t.html#a7f607687da7903fd81a7ae5281460166", null ],
    [ "num_of_networks", "struct_h_l_b__hpgp__get__networks__cnf__t.html#a5816e0aed3dba471464b3998b11e1bc5", null ]
];