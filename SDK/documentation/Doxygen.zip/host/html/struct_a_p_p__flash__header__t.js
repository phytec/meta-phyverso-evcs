var struct_a_p_p__flash__header__t =
[
    [ "flash_sections", "struct_a_p_p__flash__header__t.html#ab0063815a0fc4af80c9ff036f7700e84", null ],
    [ "num_sections", "struct_a_p_p__flash__header__t.html#a32b4c4b6b3b8601e9ef45292aa83f3e3", null ],
    [ "reserved", "struct_a_p_p__flash__header__t.html#aa4b7b4de51fb5df80a7e824210c4f286", null ],
    [ "SPI_header_magic_num", "struct_a_p_p__flash__header__t.html#ab7aadbd2beacc214261ab03c9358cbb2", null ],
    [ "SPI_header_version", "struct_a_p_p__flash__header__t.html#a876f8895994747111c51a9c9c9813c73", null ]
];