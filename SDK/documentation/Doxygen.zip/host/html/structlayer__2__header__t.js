var structlayer__2__header__t =
[
    [ "dest_mac_addr", "structlayer__2__header__t.html#a7a55c0883f9d05b01cb65dc82efd5de8", null ],
    [ "eth_type", "structlayer__2__header__t.html#a662968c964443bd59e16479f8cff5d5c", null ],
    [ "src_mac_addr", "structlayer__2__header__t.html#a3cea0c33b3d91738596355960023bd48", null ]
];