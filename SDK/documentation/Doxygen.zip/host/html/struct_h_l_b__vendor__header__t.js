var struct_h_l_b__vendor__header__t =
[
    [ "main_version", "struct_h_l_b__vendor__header__t.html#a98f1f18300ab38f87d48ed98e099ad4f", null ],
    [ "req_id", "struct_h_l_b__vendor__header__t.html#aa60ba39691fc926d844b01c553aef55d", null ],
    [ "reserved1", "struct_h_l_b__vendor__header__t.html#ab5af81c7a7da6d7402a05526c7398d25", null ],
    [ "reserved2", "struct_h_l_b__vendor__header__t.html#ad9c983036edefd5e66b77e821e150be1", null ],
    [ "reserved3", "struct_h_l_b__vendor__header__t.html#a7a364958ace1b93c7ceaa4d375322ba2", null ],
    [ "version_reserved1", "struct_h_l_b__vendor__header__t.html#a0988176e61d2179ed8b8ec2a7702c5b5", null ],
    [ "version_reserved2", "struct_h_l_b__vendor__header__t.html#aa6205295558e2b9fe298ddb7ce17bdd5", null ]
];