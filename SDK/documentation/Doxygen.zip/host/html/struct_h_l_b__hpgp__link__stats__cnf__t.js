var struct_h_l_b__hpgp__link__stats__cnf__t =
[
    [ "receive_link", "struct_h_l_b__hpgp__link__stats__cnf__t.html#aa97093f80f3c8acd48d532c6b05493f0", null ],
    [ "res_type", "struct_h_l_b__hpgp__link__stats__cnf__t.html#a4354d3431004bf828b64628b48e21a3e", null ],
    [ "transmit_link", "struct_h_l_b__hpgp__link__stats__cnf__t.html#a4f9ffaedb4aca9ca310b07a46c001cbf", null ],
    [ "transmit_link_flag", "struct_h_l_b__hpgp__link__stats__cnf__t.html#a92f380af78b3e8f311c0c09776ca4d2a", null ]
];