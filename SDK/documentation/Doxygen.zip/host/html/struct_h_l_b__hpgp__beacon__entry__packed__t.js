var struct_h_l_b__hpgp__beacon__entry__packed__t =
[
    [ "header", "struct_h_l_b__hpgp__beacon__entry__packed__t.html#a3d521ca5444b8141e57f2756362b4439", null ],
    [ "len", "struct_h_l_b__hpgp__beacon__entry__packed__t.html#a548f1a70bc6e38e0791548b4eb993423", null ],
    [ "payload", "struct_h_l_b__hpgp__beacon__entry__packed__t.html#a381244587c1e59f640cfaf69ba47fd5d", null ]
];