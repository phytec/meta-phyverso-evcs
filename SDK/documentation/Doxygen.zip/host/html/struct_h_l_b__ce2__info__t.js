var struct_h_l_b__ce2__info__t =
[
    [ "ce2_shift", "struct_h_l_b__ce2__info__t.html#a494d719d8a6f9bb387d54514abe63530", null ],
    [ "gain", "struct_h_l_b__ce2__info__t.html#a13f84cb642466286eb73e9e19c3610f3", null ],
    [ "status", "struct_h_l_b__ce2__info__t.html#afe673162448d5df2b5b629ad98e26585", null ],
    [ "total_buffer_size", "struct_h_l_b__ce2__info__t.html#a298aebbb5865fe3e8e821b809c4bdfec", null ]
];